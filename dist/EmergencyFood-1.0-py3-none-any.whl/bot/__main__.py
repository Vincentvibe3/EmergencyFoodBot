
def setupbot():
    from . import db
    from . import bot
    bot.startbot()

setupbot()